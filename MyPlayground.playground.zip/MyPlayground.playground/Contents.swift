import UIKit

var str = "Hello, playground"
print(str)

var aa : Int=55
print(aa)

aa=22
print(aa)

//상수는 값 변경 불가
let ab : Int=52
//ab=21       //Cannot assign to value: 'ab' is a 'let' constant
print(ab)

//타입 어노테이션
//자료형 별칭
typealias atype = Int
var rra : atype=42
debugPrint(rra)

//타입 추론
var x = 30
var y = 20

var xy = "\(x) \(y)"
print(xy)

//n줄 이상의 문자열 출력
var printtesting="""
asdasd
asdasd
adqweq
"""

print(printtesting)


//타입 어노테이션을 이용한 변수 생성
var n1 : Int8 = 10
var n2 : Int32 = 26

//타입 추론을 이용한 변수 생성 - 형변환 없이 연산하면 에러
//var result = n1 + n2
//n1의 자료형을 Int32로 변경해서 연산을 수행
var result = Int32(n1) + n2

print("결과:\(result)")
print(result is Int8)
print(result is Int32)


//Int16 은 -32768 ~ 32767까지 저장 가능
var n : Int16 = 10000
//결과가 40000이 되서 Overflow 발생해서 에러
//n = n + 30000

//Overflow 연산을 허용하는 &+ 연산자를 이용
n = n &+ 30000

print("n:\(n)")


var year = 2018
//year 가 윤년인지 판별하는 표현식
//4의 배수이고 100의 배수는 아닌 경우 또는
//400의 배수인 경우
var leafcheck = year % 4 == 0 && year % 100 != 0 || year % 400 == 0

print(leafcheck)

//30:00000000 00000000 00000000 00011110
//23:00000000 00000000 00000000 00010111
//결과는 22
var result1 = 30 & 23
print(result1)

var nn2 = 20
nn2 += 1
//결과는 21
print(nn2)


//1~3
let ar = 1...3
for imsi in ar{
    print(imsi)
}
//1~ 3미만 == 1~2
let ar1 = 1..<3
for imsi in ar1{
    print(imsi)
}


//year 가 윤년이면 "year년은 윤년입니다." 로 출력
//그렇지 않으면 "year년은 윤년이 아닙니다." 로 출력

 var year1 = 2018
 
 if year1 % 4 == 0 && year1 % 100 != 0 || year1 % 400 == 0{
 print("\(year1)년은 윤년입니다.")
 }else{
 print("\(year1)년은 윤년이 아닙니다.")
 }

//마우스 왼쪽 버튼과 오른쪽 버튼 클릭 그리고 더블클릭 3가지 동작을
//구분해서 수행

var action = 2
let LBUTTONCLICK = 1
let RBUTTONCLICK = 2
let LBUTTONDBLCLICK = 3

switch action{
case LBUTTONCLICK:
    print("마우스 왼쪽 버튼 클릭")
case RBUTTONCLICK:
    print("마우스 오른쪽 버튼 클릭")
case LBUTTONDBLCLICK:
    print("마우스 왼쪽 버튼 더블 클릭")
default:
    print("없는 동작")
}

//score 가 80이상이고 100이하이면 우수
//60이상이면 보통
//그 이외는 저조 라고 출력
var score = 87

switch score{
case 80...100:
    print("우수")
case 60..<80:
    print("보통")
default:
    print("저조")
}


//1부터 10까지에서 홀수만 출력
var i = 1
while i<=10{
    print(i)
    i = i + 1
}

var li = 100...104
for i in li.reversed(){
    print(i)
}



